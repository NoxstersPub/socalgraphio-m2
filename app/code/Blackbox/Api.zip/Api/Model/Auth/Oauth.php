<?php
namespace Blackbox\Api\Model\Auth;


class Oauth
{
    protected $_user = null;
    protected $_customer = null;

    /**
     * @var \Blackbox\Api\Model\UserFactory
     */
    protected $apiUserFactory;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $customerCustomerFactory;

    public function __construct(
        \Blackbox\Api\Model\UserFactory $apiUserFactory,
        \Magento\Customer\Model\CustomerFactory $customerCustomerFactory
    ) {
        $this->apiUserFactory = $apiUserFactory;
        $this->customerCustomerFactory = $customerCustomerFactory;
    }
    public function login()
    {
        $request = $this->getRequest();
        /** @var $oauthServer Mage_Oauth_Model_Server */
        $oauthServer   = Mage::getModel('oauth/server', $request);

        try {
            $token    = $oauthServer->checkAccessRequest();
            $this->_user = $this->apiUserFactory->create()->loadByToken($token);
            if ($token->getCustomerId()) {
                $this->_customer = $this->customerCustomerFactory->create()->load($token->getCustomerId());
            }
        } catch (Exception $e) {
            throw new Mage_Api2_Exception($oauthServer->reportProblem($e), \Blackbox\Api\Model\Server\Adapter\Rest::HTTP_UNAUTHORIZED);
        }
    }

    /**
     * @return null|\Blackbox\Api\Model\User
     */
    public function getUser()
    {
        return $this->_user;
    }

    /**
     * @return null|\Magento\Customer\Model\Customer
     */
    public function getCustomer()
    {
        return $this->_customer;
    }
}