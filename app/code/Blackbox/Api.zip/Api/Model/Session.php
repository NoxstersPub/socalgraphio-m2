<?php
namespace Blackbox\Api\Model;


/**
 * @method Mage_Customer_Model_Customer getCustomer()
 *
 * Class Blackbox_Api_Model_Session
 */
class Session extends Mage_Api_Model_Session
{
    protected $restMode = false;

    /**
     * @var \Blackbox\Api\Model\UserFactory
     */
    protected $apiUserFactory;

    /**
     * @var \Blackbox\Api\Model\Auth\OauthFactory
     */
    protected $apiAuthOauthFactory;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\DataObjectFactory
     */
    protected $dataObjectFactory;

    public function __construct(
        \Blackbox\Api\Model\UserFactory $apiUserFactory,
        \Blackbox\Api\Model\Auth\OauthFactory $apiAuthOauthFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\DataObjectFactory $dataObjectFactory
    ) {
        $this->dataObjectFactory = $dataObjectFactory;
        $this->apiUserFactory = $apiUserFactory;
        $this->apiAuthOauthFactory = $apiAuthOauthFactory;
        $this->storeManager = $storeManager;
    }
    public function _construct($args = null)
    {
        parent::_construct();
        if ($args['rest']) {
            $this->restMode = true;
        }
    }

    public function setRestMode($value)
    {
        $this->restMode = $value;
    }

    /**
     *  Renew user by session ID if session not expired
     *
     *  @param    string $sessId
     *  @return  boolean
     */
    protected function _renewBySessId ($sessId)
    {
        if (!$this->restMode) {
            return parent::_renewBySessId($sessId);
        }
        $user = $this->apiUserFactory->create()->loadBySessId($sessId);
        if (!$user->getId() || !$user->getSessid()) {
            return false;
        }

        if ($user->getSessid() == $sessId && !$this->isSessionExpired($user)) {
            $this->setUser($user);
            $this->setAcl(Mage::getResourceModel('api/acl')->loadAcl());

            $user->getResource()->recordLogin($user)
                ->recordSession($user);

            return true;
        }
        return false;
    }

    public function loginRest(\Zend_Controller_Request_Http $request, $namespace, $sessionName = null)
    {
        $this->restMode = true;
        /** @var \Blackbox\Api\Model\Auth\Oauth $oauth */
        $oauth = $this->apiAuthOauthFactory->create();

        $oauth->login($request);

        $this->setSessionId($oauth->getUser()->getToken()->getToken());
        $this->init($namespace, $sessionName);

        $this->setUser($oauth->getUser());
        $this->setAcl(Mage::getResourceModel('api/acl')->loadAcl());

        if ($oauth->getCustomer()) {
            $this->setCustomer($oauth->getCustomer());
        }

        $this->setStoreId(1);
        $this->setCartStoreId(1);
        $this->setProductStoreId(1);
        $this->setCategoryStoreId(1);
    }

    public function init($namespace, $sessionName=null)
    {
        if (!$this->restMode) {
            return parent::init($namespace, $sessionName);
        }
        return \Magento\Framework\Session\SessionManager::init($namespace, $sessionName);
    }



    /**
     * Configure and start session
     *
     * @param string $sessionName
     * @return Mage_Core_Model_Session_Abstract_Varien
     */
    public function start($sessionName=null)
    {
        if (!$this->restMode) {
            return parent::start($sessionName);
        }

        if (isset($_SESSION) && !$this->getSkipEmptySessionCheck()) {
            return $this;
        }

        // getSessionSaveMethod has to return correct version of handler in any case
        $moduleName = $this->getSessionSaveMethod();
        switch ($moduleName) {
            /**
             * backward compatibility with db argument (option is @deprecated after 1.12.0.2)
             */
            case 'db':
                $moduleName = 'user';
                /* @var $sessionResource Mage_Core_Model_Resource_Session */
                $sessionResource = Mage::getResourceSingleton('core/session');
                $sessionResource->setSaveHandler();
                break;
            case 'user':
                // getSessionSavePath represents static function for custom session handler setup
                call_user_func($this->getSessionSavePath());
                break;
            case 'files':
                //don't change path if it's not writable
                if (!is_writable($this->getSessionSavePath())) {
                    break;
                }
            default:
                session_save_path($this->getSessionSavePath());
                break;
        }
        session_module_name($moduleName);

        //call_user_func_array('session_set_cookie_params', $cookieParams);

        if (!empty($sessionName)) {
            $this->setSessionName($sessionName);
        }

        // potential custom logic for session id (ex. switching between hosts)
        $this->setSessionId();

        \Magento\Framework\Profiler::start(__METHOD__.'/start');
        $sessionCacheLimiter = Mage::getConfig()->getNode('global/session_cache_limiter');
        if ($sessionCacheLimiter) {
            session_cache_limiter((string)$sessionCacheLimiter);
        }

        session_start();

        \Magento\Framework\Profiler::stop(__METHOD__.'/start');

        return $this;
    }

    public function getSessionId()
    {
        if (!$this->restMode) {
            return parent::getSessionId();
        }
        return \Magento\Framework\Session\SessionManager::getSessionId(); // TODO: Change the autogenerated stub
    }

    public function setSessionId($sessId = null)
    {
        if (!$this->restMode) {
            return parent::setSessionId($sessId);
        }
        return \Magento\Framework\Session\SessionManager::setSessionId($sessId); // TODO: Change the autogenerated stub
    }

    /**
     * Check current user permission on resource
     *
     *
     * @param   string $resource
     * @return  bool
     */
    public function isAllowed($resource, $privilege = null)
    {
        if (!$this->restMode) {
            return parent::isAllowed($resource, $privilege);
        }
        return !$this->_getValidator()->process(($this->dataObjectFactory->create())->setCode($resource))->isAccessDenied();
    }

    /**
     * @return bool|Blackbox_RolesPermissions_Model_Validator
     */
    protected function _getValidator()
    {
        if (!isset($this->_validator)) {
            $customer = $this->getUser()->getCustomer();

            if ($customer->getId()) {
                $this->_validator = $validator = Mage::getModel('rolespermissions/validator')
                    ->init($this->storeManager->getWebsite()->getId(), 'api', $customer);
            } else {
                $this->_validator = false;
            }
        }
        return $this->_validator;
    }
}