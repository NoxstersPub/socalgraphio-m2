<?php
namespace Blackbox\Api\Model\Oauth;


class Api extends Mage_Api_Model_Resource_Abstract
{

    /**
     * @var \Blackbox\Api\Model\Oauth\ServerFactory
     */
    protected $apiOauthServerFactory;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $customerCustomerFactory;

    public function __construct(
        \Blackbox\Api\Model\Oauth\ServerFactory $apiOauthServerFactory,
        \Magento\Customer\Model\CustomerFactory $customerCustomerFactory
    ) {
        $this->apiOauthServerFactory = $apiOauthServerFactory;
        $this->customerCustomerFactory = $customerCustomerFactory;
    }
    /**
     * @SWG\Post(
     *   path="/oauth/login",
     *   summary="Retrieve oauth token and secret by customer credentials and client key",
     *   @SWG\Parameter(
     *      name="body",
     *      in="body",
     *      required=true,
     *      @SWG\Schema(
     *          @SWG\Property(
     *              property="login",
     *              type="string"
     *          ),
     *          @SWG\Property(
     *              property="password",
     *              type="string"
     *          ),
     *          @SWG\Property(
     *              property="consumer_key",
     *              type="string"
     *          ),
     *          @SWG\Property(
     *              property="website_id",
     *              type="integer"
     *          )
     *      )
     *   ),
     *   @SWG\Response(
     *     response=200,
     *     description="An object with oauth credentials",
     *     @SWG\Schema(
     *          type="object",
     *          @SWG\Schema(
     *              @SWG\Property(
     *                  property="response",
     *                  description="Oauth credentials",
     *                  type="object",
     *                  @SWG\Schema(
     *                      @SWG\Property(
     *                          property="oauth_token",
     *                          type="string"
     *                      ),
     *                      @SWG\Property(
     *                          property="oauth_token_secret",
     *                          type="string"
     *                      )
     *                  )
     *              )
     *          )
     *      )
     *   ),
     *   @SWG\Response(
     *     response="default",
     *     description="an ""unexpected"" error",
     *     @SWG\Schema(ref="#/definitions/error_response")
     *   )
     * )
     *
     * @param $login
     * @param $password
     * @param $consumerKey
     * @param int $websiteId
     * @return mixed
     */
    public function login($login, $password, $consumerKey, $websiteId = 1)
    {
        /** @var \Blackbox\Api\Model\Oauth\Server $server */
        $server = $this->apiOauthServerFactory->create();

        /** @var \Magento\Customer\Model\Customer $customer */
        $customer = $this->customerCustomerFactory->create();
        $customer->setWebsiteId($websiteId);
        $customer->authenticate($login, $password);

        $token = $server->generateAccessToken($consumerKey);

        $token->authorize($customer->getId(), Mage_Oauth_Model_Token::USER_TYPE_CUSTOMER);

        $response['oauth_token'] = $token->getToken();
        $response['oauth_token_secret'] = $token->getSecret();

        return $response;
    }
}